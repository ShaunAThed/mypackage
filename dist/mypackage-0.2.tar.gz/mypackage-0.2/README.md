# mypackage
This library was created to show as an example how to publish your own Pyhton package

# How to install
...
"# mypackage" 
